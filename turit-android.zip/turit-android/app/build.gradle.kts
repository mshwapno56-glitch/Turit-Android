plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ytdl = "0.18.1"

android {
    namespace = "com.turit.dm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.turit.dm"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    // fixed key: new builds install over old ones (no uninstall needed)
    signingConfigs {
        create("turit") {
            storeFile = file("turit.keystore")
            storePassword = "turit123"
            keyAlias = "turit"
            keyPassword = "turit123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("turit") }
        getByName("release") {
            signingConfig = signingConfigs.getByName("turit")
            isMinifyEnabled = false
        }
    }

    // smaller APKs: one per CPU type (+ a universal one)
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = true
        }
    }

    packaging {
        jniLibs { useLegacyPackaging = true }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")
}
