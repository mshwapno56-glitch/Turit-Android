package com.turit.dm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** The floating ⚡ button that stays over every app (needs the "display over other apps" permission). */
class BubbleService : Service() {
    companion object {
        @Volatile var running = false
        const val ACT_STOP = "com.turit.dm.STOP_BUBBLE"
        private const val CH = "bubble"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_STOP) {
            prefs().edit().putBoolean("bubble_on", false).apply()
            removeBubble()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Floating button", NotificationManager.IMPORTANCE_MIN))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, BubbleService::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Turit ⚡")
            .setContentText("Floating button is on")
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(null, "Turn off", stopPi).build())
            .setOngoing(true)
            .build()
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (bubble == null) addBubble()
        running = true
        prefs().edit().putBoolean("bubble_on", true).apply()
        return START_STICKY
    }

    private fun prefs() = getSharedPreferences("turit", Context.MODE_PRIVATE)

    private fun addBubble() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = dp(54)
        val v = TextView(this).apply {
            text = "⚡"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#1B1200"))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#FFB020"), Color.parseColor("#FF7A18"))
            ).apply { shape = GradientDrawable.OVAL }
            elevation = dp(6).toFloat()
            alpha = 0.92f
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs().getInt("bx", dp(8))
            y = prefs().getInt("by", dp(220))
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _: View, e: MotionEvent ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > dp(8)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs().edit().putInt("bx", lp.x).putInt("by", lp.y).apply()
                    } else {
                        startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(v, lp)
            bubble = v
        } catch (e: Exception) {
            // no overlay permission
            stopSelf()
        }
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    override fun onDestroy() {
        removeBubble()
        running = false
        super.onDestroy()
    }
}
