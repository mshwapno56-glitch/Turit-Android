package com.turit.dm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {
    companion object {
        const val ACT_ADD = "com.turit.dm.ADD"
        const val ACT_CANCEL = "com.turit.dm.CANCEL"
        const val X_URL = "url"
        const val X_HEIGHT = "height"
        const val X_AUDIO = "audio"
        const val X_ID = "id"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val SUMMARY_ID = 1
    }

    private val pool = Executors.newFixedThreadPool(2)
    private val active = AtomicInteger(0)
    private lateinit var nm: NotificationManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Downloads", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Finished", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun summary(): Notification =
        Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Turit")
            .setContentText("Downloading…")
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(SUMMARY_ID, summary(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        when (intent?.action) {
            ACT_ADD -> {
                val url = intent.getStringExtra(X_URL)
                if (url != null) {
                    val h = intent.getIntExtra(X_HEIGHT, 0).takeIf { it > 0 }
                    val dl = Dl(Store.nextId.getAndIncrement(), url, h, intent.getBooleanExtra(X_AUDIO, false))
                    dl.name = U.host(url)
                    Store.items.add(dl)
                    active.incrementAndGet()
                    pool.execute {
                        try { run(dl) } finally {
                            if (active.decrementAndGet() <= 0) {
                                stopForeground(STOP_FOREGROUND_REMOVE)
                                stopSelf()
                            }
                        }
                    }
                }
            }
            ACT_CANCEL -> {
                val id = intent.getIntExtra(X_ID, -1)
                Store.items.find { it.id == id }?.let { cancel(it) }
            }
        }
        if (active.get() <= 0) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun cancel(dl: Dl) {
        if (dl.state == Dl.QUEUED || dl.state == Dl.RUNNING) {
            dl.state = Dl.CANCELLED
            try { YoutubeDL.getInstance().destroyProcessById("dl${dl.id}") } catch (_: Throwable) {}
            nm.cancel(1000 + dl.id)
        }
    }

    private fun progressNote(dl: Dl): Notification {
        val cancelPi = PendingIntent.getService(
            this, dl.id,
            Intent(this, DownloadService::class.java).setAction(ACT_CANCEL).putExtra(X_ID, dl.id),
            PendingIntent.FLAG_IMMUTABLE
        )
        val act = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Cancel", cancelPi
        ).build()
        val pct = dl.pct.toInt().coerceIn(0, 100)
        val txt = buildString {
            append("$pct%")
            if (dl.speed.isNotEmpty()) append(" · ").append(dl.speed)
            val e = U.fmtEta(dl.eta)
            if (e.isNotEmpty()) append(" · ").append(e).append(" left")
        }
        return Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(dl.name)
            .setContentText(txt)
            .setProgress(100, pct, dl.pct <= 0f)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(act)
            .build()
    }

    private fun finishNote(dl: Dl, ok: Boolean) {
        val b = Notification.Builder(this, CH_DONE)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "Download complete ✓" else "Download failed")
            .setContentText(if (ok) dl.name else dl.name + " — " + dl.error.take(120))
            .setAutoCancel(true)
        val uri = dl.uri
        val pi = if (ok && uri != null) {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, dl.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            PendingIntent.getActivity(this, dl.id, view, PendingIntent.FLAG_IMMUTABLE)
        } else {
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        }
        nm.notify(2000 + dl.id, b.setContentIntent(pi).build())
    }

    private fun run(dl: Dl) {
        if (dl.state == Dl.CANCELLED) return
        dl.state = Dl.RUNNING
        nm.notify(1000 + dl.id, progressNote(dl))

        val err = Engine.ensure(this)
        if (err != null) return fail(dl, err)

        val tmp = File(getExternalFilesDir(null) ?: cacheDir, "dl/${dl.id}")
        tmp.deleteRecursively()
        tmp.mkdirs()

        // attempts, fastest first: aria2c (16 parallel connections), then plain yt-dlp.
        // YouTube changes often, so several player clients are tried in turn.
        val attempts = ArrayList<Pair<String, Boolean>>() // (youtube client, use aria2c)
        if (U.isYoutube(dl.url)) {
            attempts.add("android_vr" to true)
            attempts.add("android_vr" to false)
            attempts.add("ios" to false)
            attempts.add("" to false)
        } else {
            attempts.add("" to true)
            attempts.add("" to false)
        }
        var lastErr = ""
        var ok = false
        var lastNote = 0L
        for ((client, aria) in attempts) {
            if (dl.state == Dl.CANCELLED) return
            dl.pct = 0f
            dl.speed = ""
            val req = YoutubeDLRequest(dl.url)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("--windows-filenames")
            req.addOption("--newline")
            req.addOption("--retries", "10")
            req.addOption("-f", U.selector(dl.height, dl.audio))
            if (aria) {
                req.addOption("--downloader", "libaria2c.so")
                req.addOption("--downloader-args", "aria2c:-x16 -s16 -k1M --file-allocation=none --summary-interval=1")
            } else {
                req.addOption("-N", "16")
                req.addOption("--http-chunk-size", "10M")
            }
            if (dl.audio) {
                req.addOption("-x")
                req.addOption("--audio-format", "m4a")
            } else {
                req.addOption("--merge-output-format", "mp4")
            }
            if (client.isNotEmpty()) req.addOption("--extractor-args", "youtube:player_client=$client")
            req.addOption("-o", tmp.absolutePath + "/%(title).100s.%(ext)s")
            try {
                YoutubeDL.getInstance().execute(req, "dl${dl.id}") { progress, eta, line ->
                    if (progress >= 0f) dl.pct = progress
                    if (eta > 0) dl.eta = eta
                    // yt-dlp: "at 5.2MiB/s"   aria2c: "(10%) CN:16 DL:3.4MiB ETA:12s"
                    Regex("at\\s+([0-9.]+\\s?\\S*/s)").find(line)?.let { dl.speed = it.groupValues[1] }
                    Regex("DL:([0-9.]+[KMG]?i?B)").find(line)?.let { dl.speed = it.groupValues[1] + "/s" }
                    Regex("\\((\\d+)%\\)").find(line)?.let { dl.pct = it.groupValues[1].toFloat() }
                    Regex("ETA:([0-9hms]+)").find(line)?.let { dl.eta = U.parseEta(it.groupValues[1]) }
                    Regex("Destination:\\s*(.+)").find(line)?.let { dl.name = File(it.groupValues[1].trim()).name }
                    val now = System.currentTimeMillis()
                    if (now - lastNote > 800 && dl.state == Dl.RUNNING) {
                        lastNote = now
                        nm.notify(1000 + dl.id, progressNote(dl))
                    }
                }
                ok = true
                break
            } catch (e: Throwable) {
                if (dl.state == Dl.CANCELLED) return
                lastErr = e.message ?: "unknown error"
                tmp.listFiles()?.forEach { it.delete() }
            }
        }
        if (dl.state == Dl.CANCELLED) {
            tmp.deleteRecursively()
            return
        }
        if (!ok) {
            tmp.deleteRecursively()
            return fail(dl, lastErr.lines().lastOrNull { it.isNotBlank() } ?: lastErr)
        }

        // move into Downloads/Turit/<category>
        val f = tmp.listFiles()
            ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() }
        if (f == null) {
            tmp.deleteRecursively()
            return fail(dl, "File not found")
        }
        try {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Turit/" + U.category(f.extension))
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return fail(dl, "Could not save")
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out, 256 * 1024) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(uri, done, null, null)
            dl.uri = uri
            dl.mime = mime
            dl.name = f.name
        } catch (e: Throwable) {
            tmp.deleteRecursively()
            return fail(dl, e.message ?: "Could not save")
        }
        tmp.deleteRecursively()
        dl.pct = 100f
        dl.state = Dl.DONE
        nm.cancel(1000 + dl.id)
        finishNote(dl, true)
    }

    private fun fail(dl: Dl, msg: String) {
        dl.error = msg
        dl.state = Dl.ERROR
        nm.cancel(1000 + dl.id)
        finishNote(dl, false)
    }

    override fun onDestroy() {
        pool.shutdown()
        super.onDestroy()
    }
}
