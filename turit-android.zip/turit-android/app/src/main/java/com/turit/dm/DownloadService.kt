package com.turit.dm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.IBinder
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {
    companion object {
        const val ACT_ADD = "com.turit.dm.ADD"
        const val ACT_CANCEL = "com.turit.dm.CANCEL"
        const val X_URL = "url"
        const val X_HEIGHT = "height"
        const val X_AUDIO = "audio"
        const val X_ID = "id"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val SUMMARY_ID = 1
    }

    private val pool = Executors.newFixedThreadPool(2)
    private val active = AtomicInteger(0)
    private lateinit var nm: NotificationManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Downloads", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Finished", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun summary(): Notification =
        Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Turit")
            .setContentText("Downloading…")
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(SUMMARY_ID, summary(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        when (intent?.action) {
            ACT_ADD -> {
                val url = intent.getStringExtra(X_URL)
                if (url != null) {
                    val h = intent.getIntExtra(X_HEIGHT, 0).takeIf { it > 0 }
                    val dl = Dl(Store.nextId.getAndIncrement(), url, h, intent.getBooleanExtra(X_AUDIO, false))
                    dl.name = U.host(url)
                    Store.items.add(dl)
                    active.incrementAndGet()
                    pool.execute {
                        try { run(dl) } finally {
                            if (active.decrementAndGet() <= 0) {
                                stopForeground(STOP_FOREGROUND_REMOVE)
                                stopSelf()
                            }
                        }
                    }
                }
            }
            ACT_CANCEL -> {
                val id = intent.getIntExtra(X_ID, -1)
                Store.items.find { it.id == id }?.let { cancel(it) }
            }
        }
        if (active.get() <= 0) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun cancel(dl: Dl) {
        if (dl.state == Dl.QUEUED || dl.state == Dl.RUNNING) {
            dl.state = Dl.CANCELLED
            dl.procs.forEach { p -> try { YoutubeDL.getInstance().destroyProcessById(p) } catch (_: Throwable) {} }
            nm.cancel(1000 + dl.id)
        }
    }

    private fun progressNote(dl: Dl): Notification {
        val cancelPi = PendingIntent.getService(
            this, dl.id,
            Intent(this, DownloadService::class.java).setAction(ACT_CANCEL).putExtra(X_ID, dl.id),
            PendingIntent.FLAG_IMMUTABLE
        )
        val act = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Cancel", cancelPi
        ).build()
        val pct = dl.pct.toInt().coerceIn(0, 100)
        val txt = buildString {
            append("$pct%")
            if (dl.total > 0) append(" · ").append(U.fmtBytes(dl.done)).append(" / ").append(U.fmtBytes(dl.total))
            if (dl.speed.isNotEmpty()) append(" · ").append(dl.speed)
            val e = U.fmtEta(dl.eta)
            if (e.isNotEmpty()) append(" · ").append(e).append(" left")
        }
        return Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(dl.name)
            .setContentText(txt)
            .setProgress(100, pct, dl.pct <= 0f)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(act)
            .build()
    }

    private fun finishNote(dl: Dl, ok: Boolean) {
        val b = Notification.Builder(this, CH_DONE)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "Download complete ✓" else "Download failed")
            .setContentText(if (ok) dl.name else dl.name + " — " + dl.error.take(120))
            .setAutoCancel(true)
        val uri = dl.uri
        val pi = if (ok && uri != null) {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, dl.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            PendingIntent.getActivity(this, dl.id, view, PendingIntent.FLAG_IMMUTABLE)
        } else {
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        }
        nm.notify(2000 + dl.id, b.setContentIntent(pi).build())
    }

    private class Att(val client: String, val aria: Boolean, val skip: Boolean, val label: String)

    /** Reads progress info out of one yt-dlp / aria2c output line. */
    private fun applyLine(dl: Dl, ln: String, progress: Float, eta: Long) {
        if (progress >= 0f) dl.pct = progress
        // yt-dlp: "[download]  12.3% of ~ 45.67MiB at 5.20MiB/s ETA 00:07"
        Regex("of\\s+~?\\s*([0-9.]+)\\s*([KMG]?i?B)").find(ln)?.let { dl.total = U.toBytes(it.groupValues[1], it.groupValues[2]) }
        Regex("at\\s+~?\\s*([0-9.]+)\\s*([KMG]?i?B)/s").find(ln)?.let {
            dl.speedBps = U.toBytes(it.groupValues[1], it.groupValues[2])
            dl.speed = it.groupValues[1] + " " + it.groupValues[2] + "/s"
        }
        // aria2c: "[#1a2b3c 5.2MiB/50MiB(10%) CN:16 DL:3.4MiB ETA:12s]"
        Regex("([0-9.]+)([KMG]?i?B)/([0-9.]+)([KMG]?i?B)\\((\\d+)%\\)").find(ln)?.let {
            dl.done = U.toBytes(it.groupValues[1], it.groupValues[2])
            dl.total = U.toBytes(it.groupValues[3], it.groupValues[4])
            dl.pct = it.groupValues[5].toFloat()
        }
        Regex("DL:([0-9.]+)([KMG]?i?B)").find(ln)?.let {
            dl.speedBps = U.toBytes(it.groupValues[1], it.groupValues[2])
            dl.speed = it.groupValues[1] + " " + it.groupValues[2] + "/s"
        }
        Regex("Destination:\\s*(.+)").find(ln)?.let { dl.name = File(it.groupValues[1].trim()).name }
        if (dl.total > 0 && dl.done == 0L || ln.contains("[download]")) {
            if (dl.total > 0) dl.done = (dl.total * (dl.pct / 100.0)).toLong()
        }
        // time left: our own estimate (size left / speed), else what the tool says
        if (dl.speedBps > 0 && dl.total > dl.done) dl.eta = (dl.total - dl.done) / dl.speedBps
        else if (eta > 0) dl.eta = eta
        Regex("ETA:([0-9hms]+)").find(ln)?.let { if (dl.eta <= 0) dl.eta = U.parseEta(it.groupValues[1]) }
        val now = System.currentTimeMillis()
        if (now - dl.lastNote > 800 && dl.state == Dl.RUNNING) {
            dl.lastNote = now
            nm.notify(1000 + dl.id, progressNote(dl))
        }
    }

    /**
     * One yt-dlp run. Returns null on success, otherwise the error text.
     * [claim] is asked when the first real download data arrives: false = another attempt already won.
     */
    private fun runAttempt(dl: Dl, att: Att, dir: File, proc: String, claim: () -> Boolean): String? {
        dir.mkdirs()
        dl.procs.add(proc)
        val req = YoutubeDLRequest(dl.url)
        req.addOption("--no-playlist")
        req.addOption("--no-mtime")
        req.addOption("--windows-filenames")
        req.addOption("--newline")
        req.addOption("--retries", "10")
        req.addOption("--socket-timeout", "15")
        req.addOption("--extractor-retries", "1")
        req.addOption("-f", U.selector(dl.height, dl.audio))
        if (att.aria) {
            req.addOption("--downloader", "libaria2c.so")
            req.addOption("--downloader-args", "aria2c:-x16 -s16 -k1M --file-allocation=none --summary-interval=1")
        } else {
            req.addOption("-N", "16")
            req.addOption("--http-chunk-size", "10M")
        }
        if (dl.audio) {
            req.addOption("-x")
            req.addOption("--audio-format", "m4a")
        } else {
            req.addOption("--merge-output-format", "mp4")
        }
        if (att.client.isNotEmpty()) {
            val ea = "youtube:player_client=${att.client}" + if (att.skip) ";player_skip=webpage,js" else ""
            req.addOption("--extractor-args", ea)
        }
        req.addOption("-o", dir.absolutePath + "/%(title).100s.%(ext)s")
        var claimed = false
        var lost = false
        return try {
            YoutubeDL.getInstance().execute(req, proc) { progress, eta, line ->
                val ln: String = line ?: ""
                if (lost) return@execute
                if (ln.isNotBlank() && !claimed) dl.log = att.label + ": " + ln.take(120)
                val data = (ln.contains("[download]") && ln.contains("%")) || ln.contains("DL:") || progress > 0f
                if (data && !claimed) {
                    if (claim()) {
                        claimed = true
                        dl.phase = ""
                        dl.log = ""
                        dl.pct = 0f; dl.done = 0; dl.total = 0; dl.speed = ""; dl.speedBps = 0; dl.eta = 0
                    } else {
                        lost = true
                        try { YoutubeDL.getInstance().destroyProcessById(proc) } catch (_: Throwable) {}
                        return@execute
                    }
                }
                if (claimed) applyLine(dl, ln, progress, eta)
            }
            // finished without ever printing progress (tiny file): claim now
            if (!claimed && !claim()) "lost" else null
        } catch (e: Throwable) {
            if (lost) "lost" else (e.message ?: "unknown error").lines().lastOrNull { it.isNotBlank() }?.take(160) ?: "unknown error"
        }
    }

    private fun killProc(dl: Dl, proc: String) {
        try { YoutubeDL.getInstance().destroyProcessById(proc) } catch (_: Throwable) {}
    }

    /**
     * Runs the attempts at the same time; the first one that starts receiving data wins and the
     * others are stopped. Gives up if nothing starts within [timeoutMs].
     * Returns (folder of the finished download or null, error text).
     */
    private fun runGroup(dl: Dl, atts: List<Att>, tmp: File, tag: String, timeoutMs: Long): Pair<File?, String> {
        val winner = AtomicInteger(-1)
        val res = arrayOfNulls<String>(atts.size) // null = still running, "" = finished OK
        val threads = atts.mapIndexed { i, a ->
            Thread {
                val r = runAttempt(dl, a, File(tmp, "$tag$i"), "dl${dl.id}_$tag$i") { winner.compareAndSet(-1, i) || winner.get() == i }
                res[i] = r ?: ""
            }.also { it.start() }
        }
        val t0 = System.currentTimeMillis()
        var timedOut = false
        while (threads.any { it.isAlive }) {
            Thread.sleep(250)
            if (dl.state == Dl.CANCELLED) {
                atts.indices.forEach { killProc(dl, "dl${dl.id}_$tag$it") }
                break
            }
            val w = winner.get()
            if (w >= 0) {
                atts.indices.filter { it != w }.forEach { killProc(dl, "dl${dl.id}_$tag$it") }
            } else if (System.currentTimeMillis() - t0 > timeoutMs) {
                timedOut = true
                atts.indices.forEach { killProc(dl, "dl${dl.id}_$tag$it") }
                break
            }
        }
        threads.forEach { it.join(20000) }
        val w = winner.get()
        if (w >= 0 && res[w] == "") return Pair(File(tmp, "$tag$w"), "")
        val msg = atts.indices
            .filter { res[it] != "lost" }
            .joinToString("\n") { atts[it].label + ": " + (res[it] ?: "stopped") }
        return Pair(null, (if (timedOut) "timed out while preparing\n" else "") + msg)
    }

    private fun run(dl: Dl) {
        if (dl.state == Dl.CANCELLED) return
        dl.state = Dl.RUNNING
        dl.phase = "Starting engine…"
        nm.notify(1000 + dl.id, progressNote(dl))

        val err = Engine.ensure(this)
        if (err != null) return fail(dl, err)

        val tmp = File(getExternalFilesDir(null) ?: cacheDir, "dl/${dl.id}")
        tmp.deleteRecursively()
        tmp.mkdirs()

        val errs = ArrayList<String>()
        var outDir: File?
        if (U.isYoutube(dl.url)) {
            // two YouTube "clients" at once: whichever answers first is used
            dl.phase = "Preparing… (checking YouTube)"
            val r = runGroup(dl, listOf(Att("android_vr", false, true, "android_vr"), Att("ios", false, false, "ios")), tmp, "a", 75_000)
            outDir = r.first
            if (r.second.isNotEmpty()) errs.add(r.second)
            if (outDir == null && dl.state != Dl.CANCELLED) {
                dl.phase = "Preparing… (trying another way)"
                val r2 = runGroup(dl, listOf(Att("", false, false, "default")), tmp, "b", 120_000)
                outDir = r2.first
                if (r2.second.isNotEmpty()) errs.add(r2.second)
            }
        } else {
            // other sites: aria2c (16 connections) first, plain yt-dlp as backup
            dl.phase = "Preparing…"
            val r = runGroup(dl, listOf(Att("", true, false, "aria2c")), tmp, "a", 180_000)
            outDir = r.first
            if (r.second.isNotEmpty()) errs.add(r.second)
            if (outDir == null && dl.state != Dl.CANCELLED) {
                val r2 = runGroup(dl, listOf(Att("", false, false, "plain")), tmp, "b", 180_000)
                outDir = r2.first
                if (r2.second.isNotEmpty()) errs.add(r2.second)
            }
        }
        if (dl.state == Dl.CANCELLED) {
            tmp.deleteRecursively()
            return
        }
        if (outDir == null) {
            tmp.deleteRecursively()
            return fail(dl, errs.joinToString("\n"))
        }

        // move into Downloads/Turit/<category>
        val f = outDir.listFiles()
            ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() }
        if (f == null) {
            tmp.deleteRecursively()
            return fail(dl, "File not found")
        }
        try {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Turit/" + U.category(f.extension))
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return fail(dl, "Could not save")
            contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out, 256 * 1024) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(uri, done, null, null)
            dl.uri = uri
            dl.mime = mime
            dl.name = f.name
            dl.total = f.length()
            dl.done = f.length()
        } catch (e: Throwable) {
            tmp.deleteRecursively()
            return fail(dl, e.message ?: "Could not save")
        }
        tmp.deleteRecursively()
        dl.pct = 100f
        dl.state = Dl.DONE
        nm.cancel(1000 + dl.id)
        finishNote(dl, true)
    }

    private fun fail(dl: Dl, msg: String) {
        dl.error = msg
        dl.state = Dl.ERROR
        nm.cancel(1000 + dl.id)
        finishNote(dl, false)
    }

    override fun onDestroy() {
        pool.shutdown()
        super.onDestroy()
    }
}
