package com.turit.dm

import android.content.Context
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/** One download as shown in the list. */
class Dl(val id: Int, val url: String, val height: Int?, val audio: Boolean) {
    @Volatile var name: String = ""
    @Volatile var pct: Float = 0f
    @Volatile var eta: Long = 0
    @Volatile var speed: String = ""
    @Volatile var phase: String = ""
    @Volatile var log: String = ""
    @Volatile var total: Long = 0      // size of the file being downloaded, bytes
    @Volatile var done: Long = 0       // bytes downloaded so far
    @Volatile var speedBps: Long = 0
    @Volatile var lastNote: Long = 0
    val procs = java.util.concurrent.CopyOnWriteArrayList<String>()
    @Volatile var state: Int = QUEUED
    @Volatile var error: String = ""
    @Volatile var uri: android.net.Uri? = null
    @Volatile var mime: String = "*/*"

    companion object {
        const val QUEUED = 0
        const val RUNNING = 1
        const val DONE = 2
        const val ERROR = 3
        const val CANCELLED = 4
    }
}

object Store {
    val items = CopyOnWriteArrayList<Dl>()
    val nextId = AtomicInteger(1)
}

/** Starts yt-dlp / ffmpeg (unpacks them on first use). */
object Engine {
    private val lock = Any()
    private var ready = false

    /** null = ready, otherwise an error text */
    fun ensure(ctx: Context): String? = synchronized(lock) {
        if (ready) return null
        try {
            YoutubeDL.getInstance().init(ctx.applicationContext)
            FFmpeg.getInstance().init(ctx.applicationContext)
            Aria2c.getInstance().init(ctx.applicationContext)
            ready = true
            null
        } catch (e: Throwable) {
            e.message ?: "engine start failed"
        }
    }
}

/** YouTube changes weekly; the yt-dlp inside the app gets old, so refresh it once a day. */
fun Engine.updateDaily(ctx: Context) {
    try {
        val p = ctx.getSharedPreferences("turit", Context.MODE_PRIVATE)
        val last = p.getLong("ytdlp_updated", 0L)
        if (System.currentTimeMillis() - last < 24L * 3600 * 1000) return
        YoutubeDL.getInstance().updateYoutubeDL(ctx.applicationContext)
        p.edit().putLong("ytdlp_updated", System.currentTimeMillis()).apply()
    } catch (_: Throwable) {
    }
}

object U {
    private val URL_RE = Regex("https?://[^\\s\"'<>]+")

    fun firstUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val m = URL_RE.find(text) ?: return null
        return m.value.trimEnd('.', ',', ')', ']', ';', '!')
    }

    fun host(url: String): String =
        try { java.net.URI(url).host?.removePrefix("www.") ?: url } catch (_: Exception) { url }

    fun isYoutube(url: String): Boolean {
        val h = host(url).lowercase()
        return h == "youtu.be" || h == "youtube.com" || h.endsWith(".youtube.com")
    }

    /** Same quality rule as the Windows app: H.264 + AAC so the file plays on any phone. */
    fun selector(height: Int?, audio: Boolean): String {
        if (audio) return "ba[ext=m4a]/ba/b"
        val h = height ?: 4320
        return "bv*[height<=$h][vcodec~='^(avc|h264)']+ba[ext=m4a]/b[height<=$h][ext=mp4]/bv*[height<=$h]+ba/b[height<=$h]/b"
    }

    fun category(ext: String): String = when (ext.lowercase()) {
        "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "m4v", "ts" -> "Video"
        "mp3", "m4a", "aac", "wav", "flac", "ogg", "opus" -> "Music"
        "apk", "xapk", "exe", "msi" -> "Programs"
        "zip", "rar", "7z", "tar", "gz" -> "Compressed"
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub" -> "Documents"
        "jpg", "jpeg", "png", "gif", "webp" -> "Images"
        else -> "Other"
    }

    /** aria2c prints "ETA:1m2s" / "ETA:45s" */
    fun parseEta(t: String): Long {
        var total = 0L
        Regex("(\\d+)([hms])").findAll(t).forEach {
            val n = it.groupValues[1].toLong()
            total += when (it.groupValues[2]) { "h" -> n * 3600; "m" -> n * 60; else -> n }
        }
        return total
    }

    private fun verParts(v: String): List<Int> =
        v.trim().trimStart('v', 'V').split('.').map { p -> p.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }

    /** true when [latest] is a higher version number than [current] */
    fun isNewer(latest: String, current: String): Boolean {
        val a = verParts(latest)
        val b = verParts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** "5.2" + "MiB" -> bytes */
    fun toBytes(num: String, unit: String): Long {
        val n = num.toDoubleOrNull() ?: return 0
        val u = unit.uppercase()
        val mul = when {
            u.startsWith("G") -> 1024.0 * 1024 * 1024
            u.startsWith("M") -> 1024.0 * 1024
            u.startsWith("K") -> 1024.0
            else -> 1.0
        }
        return (n * mul).toLong()
    }

    fun fmtBytes(b: Long): String = when {
        b >= 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1024L * 1024 -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1024 -> String.format(java.util.Locale.US, "%.0f KB", b / 1024.0)
        else -> "$b B"
    }

    fun fmtEta(sec: Long): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) "${h}h ${m}m" else if (m > 0) "${m}m ${s}s" else "${s}s"
    }
}
