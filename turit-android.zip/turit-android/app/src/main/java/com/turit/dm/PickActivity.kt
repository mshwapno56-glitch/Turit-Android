package com.turit.dm

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * Quality picker. The link comes from: the paste box (EXTRA_URL), the Share menu,
 * or - when opened from the floating ⚡ button - the clipboard (copy link first).
 */
class PickActivity : Activity() {
    companion object {
        const val EXTRA_URL = "url"
    }

    private var handled = false
    private var shown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handled = false
    }

    // the clipboard can only be read once the window has focus
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !handled && !shown) {
            handled = true
            start()
        }
    }

    private fun start() {
        var url = U.firstUrl(intent?.getStringExtra(EXTRA_URL))
        if (url == null) url = U.firstUrl(intent?.getStringExtra(Intent.EXTRA_TEXT))
        if (url == null) {
            try {
                val cm = getSystemService(ClipboardManager::class.java)
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) url = U.firstUrl(clip.getItemAt(0).coerceToText(this)?.toString())
            } catch (_: Exception) {}
        }
        if (url == null) {
            Toast.makeText(this, "Copy the video link first (Share → Copy link)", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        showQualities(url)
    }

    private fun showQualities(url: String) {
        shown = true
        val labels = arrayOf(
            "⭐ Best quality",
            "1080p · MP4 (plays on phones)",
            "720p · MP4",
            "480p · MP4",
            "360p · MP4",
            "🎵 Audio only (M4A)"
        )
        val heights = intArrayOf(0, 1080, 720, 480, 360, 0)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("⚡ " + U.host(url))
            .setItems(labels) { _, which ->
                val i = Intent(this, DownloadService::class.java)
                    .setAction(DownloadService.ACT_ADD)
                    .putExtra(DownloadService.X_URL, url)
                    .putExtra(DownloadService.X_HEIGHT, heights[which])
                    .putExtra(DownloadService.X_AUDIO, which == 5)
                startForegroundService(i)
                Toast.makeText(this, "Added to Turit ✓", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Cancel") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }
}
