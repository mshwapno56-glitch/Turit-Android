package com.turit.dm

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private lateinit var bubbleBtn: Button
    private lateinit var batteryBtn: Button
    private lateinit var empty: TextView
    private lateinit var input: EditText
    private val rows = HashMap<Int, Row>()

    private class Row(val root: LinearLayout, val title: TextView, val meta: TextView, val bar: ProgressBar, val act: Button)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int = 12): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun btn(text: String, primary: Boolean = false): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(if (primary) Color.parseColor("#1B1200") else Color.WHITE)
        background = if (primary) round(Color.parseColor("#FFB020"), 10) else round(Color.parseColor("#262D3D"), 10)
        setPadding(dp(14), dp(8), dp(14), dp(8))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        // header
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        ht.addView(TextView(this).apply { text = "Turit"; textSize = 22f; setTextColor(Color.parseColor("#FFB020")); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        ht.addView(TextView(this).apply { text = "Lightning-fast downloader"; setTextColor(Color.parseColor("#8B95AB")) })
        head.addView(ht)
        root.addView(head)

        // how to
        root.addView(TextView(this).apply {
            text = "How to use: in YouTube, Facebook etc. tap Share → Copy link, then tap the floating ⚡ button. Pick a quality and the download starts."
            setTextColor(Color.parseColor("#C9D1E0"))
            setPadding(dp(2), dp(16), dp(2), dp(10))
        })

        bubbleBtn = btn("", true)
        bubbleBtn.setOnClickListener { toggleBubble() }
        root.addView(bubbleBtn, matchWrap())

        batteryBtn = btn("🔋 Remove battery limit (to keep running in background)")
        batteryBtn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        root.addView(batteryBtn, matchWrap(6))

        // paste box
        val pasteRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Paste link here"
            setHintTextColor(Color.parseColor("#6B7690"))
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
            background = round(Color.parseColor("#171B24"), 10)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        pasteRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val go = btn("Download", true)
        go.setOnClickListener {
            val u = U.firstUrl(input.text.toString())
            if (u != null) {
                startActivity(Intent(this, PickActivity::class.java).putExtra(PickActivity.EXTRA_URL, u))
                input.setText("")
            } else input.error = "Enter a valid link"
        }
        pasteRow.addView(go)
        root.addView(pasteRow, matchWrap(10))

        root.addView(TextView(this).apply {
            text = "Downloads"
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(20), 0, dp(6))
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        empty = TextView(this).apply {
            text = "No downloads yet.\nFiles are saved in Downloads/Turit."
            setTextColor(Color.parseColor("#8B95AB"))
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(empty)

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        // first use: unpack the download engine in the background so the first download starts quickly
        Thread { Engine.ensure(this) }.start()
    }

    private fun matchWrap(top: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
        }

    private fun toggleBubble() {
        if (BubbleService.running) {
            startService(Intent(this, BubbleService::class.java).setAction(BubbleService.ACT_STOP))
        } else if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            startForegroundService(Intent(this, BubbleService::class.java))
        }
        ui.postDelayed({ refresh() }, 400)
    }

    override fun onResume() {
        super.onResume()
        // bring the bubble back if it was on before
        val on = getSharedPreferences("turit", Context.MODE_PRIVATE).getBoolean("bubble_on", false)
        if (on && !BubbleService.running && Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, BubbleService::class.java))
        }
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 500)
        }
    }

    private fun refresh() {
        bubbleBtn.text = when {
            BubbleService.running -> "⚡ Turn off floating button"
            !Settings.canDrawOverlays(this) -> "⚡ Turn on floating button (grant permission first)"
            else -> "⚡ Turn on floating button"
        }
        val pm = getSystemService(PowerManager::class.java)
        batteryBtn.visibility = if (pm.isIgnoringBatteryOptimizations(packageName)) View.GONE else View.VISIBLE

        val items = Store.items.toList().reversed()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        for (d in items) {
            val r = rows.getOrPut(d.id) { makeRow(d).also { list.addView(it.root, 0) } }
            update(r, d)
        }
    }

    private fun makeRow(d: Dl): Row {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(Color.parseColor("#171B24"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = matchWrap(8)
        }
        val title = TextView(this).apply {
            setTextColor(Color.WHITE)
            maxLines = 2
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val meta = TextView(this).apply { setTextColor(Color.parseColor("#8B95AB")); textSize = 12f }
        val act = btn("")
        root.addView(title)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(14)))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bottom.addView(meta, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(act)
        root.addView(bottom)
        return Row(root, title, meta, bar, act)
    }

    private fun update(r: Row, d: Dl) {
        r.title.text = d.name
        r.bar.progress = d.pct.toInt().coerceIn(0, 100)
        r.bar.isIndeterminate = d.state == Dl.RUNNING && d.pct <= 0f
        when (d.state) {
            Dl.QUEUED -> { r.meta.text = "Waiting…"; setAct(r, "Cancel") { cancel(d) } }
            Dl.RUNNING -> {
                val e = U.fmtEta(d.eta)
                r.meta.text = "${d.pct.toInt()}%" + (if (d.speed.isNotEmpty()) " · ${d.speed}" else "") + (if (e.isNotEmpty()) " · $e left" else "")
                setAct(r, "Cancel") { cancel(d) }
            }
            Dl.DONE -> {
                r.meta.text = "Done ✓"
                setAct(r, "Open") {
                    val u = d.uri
                    if (u != null) {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, d.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        } catch (_: Exception) {}
                    }
                }
            }
            Dl.ERROR -> { r.meta.text = "Failed: " + d.error.take(140); setAct(r, "Retry") { retry(d) } }
            else -> { r.meta.text = "Cancelled"; setAct(r, "Retry") { retry(d) } }
        }
    }

    private fun setAct(r: Row, text: String, f: () -> Unit) {
        if (r.act.text.toString() != text) r.act.text = text
        r.act.setOnClickListener { f() }
    }

    private fun cancel(d: Dl) {
        startForegroundService(Intent(this, DownloadService::class.java).setAction(DownloadService.ACT_CANCEL).putExtra(DownloadService.X_ID, d.id))
    }

    private fun retry(d: Dl) {
        rows.remove(d.id)?.let { list.removeView(it.root) }
        Store.items.remove(d)
        startForegroundService(
            Intent(this, DownloadService::class.java).setAction(DownloadService.ACT_ADD)
                .putExtra(DownloadService.X_URL, d.url)
                .putExtra(DownloadService.X_HEIGHT, d.height ?: 0)
                .putExtra(DownloadService.X_AUDIO, d.audio)
        )
    }
}
